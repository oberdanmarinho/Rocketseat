﻿namespace Journey.Communication.Enums;
public enum ActivityStatus
{
    Pending = 0,
    Done = 1,
}
